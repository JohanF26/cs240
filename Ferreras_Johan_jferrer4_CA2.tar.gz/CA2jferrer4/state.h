#ifndef STATE_H_
#define STATE_H_

enum State {NY, PA, RI, NH, VT, MA, CT, ME};

#endif
